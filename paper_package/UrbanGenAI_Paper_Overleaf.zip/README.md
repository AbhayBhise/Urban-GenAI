# UrbanGen AI: IEEE Conference Paper Submission Package

This self-contained folder contains everything needed to compile and submit the IEEE Conference research paper for **UrbanGen AI**.

---

## 📁 Package Structure

```text
paper_package/
├── IEEE_Conference_Paper.tex     # Full IEEE double-column conference paper source
├── main.tex                      # Duplicate of the TeX source (for Overleaf auto-recognition)
├── README.md                     # Asset index & Overleaf instructions
├── UrbanGenAI_Paper_Overleaf.zip # 1-Click ready-to-upload zip file for Overleaf
└── figures/                      # EXACT 9 figures referenced in the paper
    ├── fig_ae_convergence.png
    ├── fig_psnr_comparison.png
    ├── fig_ae_crisp_restoration.png
    ├── fig_classifier_metrics.png
    ├── fig_vae_tradeoff.png
    ├── fig_vae_multi_interpolation.png
    ├── fig_gan_dynamics.png
    ├── fig_gan_diverse_generation.png
    └── fig_multimodel_loss_bars.png
```

---

## 🖼️ Exact Figures Index (What Goes Where in the Paper)

| # | File Name in `figures/` | Paper Section | LaTeX Label | Figure Description |
|---|---|---|---|---|
| **1** | `fig_ae_convergence.png` | Sec. IV-B | `\label{fig:ae_loss}` | Denoising U-Net Autoencoder Reconstruction MSE Loss curve (50 epochs) |
| **2** | `fig_psnr_comparison.png` | Sec. IV-B | `\label{fig:psnr_comp}` | Class-wise PSNR comparison: Baseline Bottleneck AE (25.0 dB) vs. Proposed Skip-AE (29.7 dB) |
| **3** | `fig_ae_crisp_restoration.png` | Sec. IV-B | `\label{fig:ae_crisp}` | Visual qualitative restoration grid (Ground Truth, Noisy $\sigma=0.15$, Restored Skip-AE) across 4 representative land-cover classes |
| **4** | `fig_classifier_metrics.png` | Sec. IV-C | `\label{fig:cls_metrics}` | Validation Accuracy (98.1%) & Cross-Entropy Loss for ResNet-18 Territorial Classifier |
| **5** | `fig_vae_tradeoff.png` | Sec. IV-D | `\label{fig:vae_tradeoff}` | Dual-objective Spatial VAE optimization: Reconstruction Loss vs. KL Divergence ($41.6$ nats) |
| **6** | `fig_vae_multi_interpolation.png` | Sec. IV-D | `\label{fig:vae_multi_interp}` | Multi-pair continuous latent space interpolation across $\alpha \in [0, 1]$ across diverse urban archetypes |
| **7** | `fig_gan_dynamics.png` | Sec. IV-E | `\label{fig:gan_dynamics}` | Adversarial training loss curves for Discriminator ($D=1.639$) and Generator ($G=1.232$) |
| **8** | `fig_gan_diverse_generation.png` | Sec. IV-E | `\label{fig:gan_samples}` | 21-class conditional aerial synthesis grid demonstrating diversity without mode collapse |
| **9** | `fig_multimodel_loss_bars.png` | Sec. IV-F | `\label{fig:loss_bars}` | Multi-model benchmark initial vs. final 50-epoch loss comparison across all 6 specialized architectures (log scale) |

> **Note on Non-Overlapping Legends**: All figure legends have been positioned with clean headroom and non-colliding layout boxes. No bars or line plots intersect with any legends or titles.

---

## 🚀 How to Use with Overleaf

### Option A: Upload Zip (Fastest & Easiest)
1. Go to [Overleaf](https://www.overleaf.com/).
2. Click **New Project** $\to$ **Upload Project**.
3. Select `UrbanGenAI_Paper_Overleaf.zip` from this folder.
4. Overleaf will unpack all files and compile automatically.

### Option B: Replace Assets in Existing Project
1. Open your existing Overleaf project.
2. In the left file tree, delete the old `figures/` folder.
3. Click **Upload** $\to$ drag and drop the `figures/` folder (or all 9 PNG files inside it).
4. Replace your `main.tex` content with `IEEE_Conference_Paper.tex`.
5. Click **Recompile**.
